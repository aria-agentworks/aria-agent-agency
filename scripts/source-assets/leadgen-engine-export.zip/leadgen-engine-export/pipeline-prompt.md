# LEAD GENERATION PIPELINE — scheduled run

Work through these steps in order. Never fabricate business information. One website at a time.

## 1) CONFIG
Read the LeadConfig record. If `enabled` is false, or `target_location`, `sender_name`,
`sender_email`, or `physical_address` are empty: STOP. Post a one-line notice that the run
was skipped and which field is missing. Do nothing else.

## 2) PROCESS REPLIES FIRST
Check the inbox. For any reply from a business that exists in Prospect (match sender email):
- If they ask to stop / unsubscribe / not be emailed: set `outreach_status=opted_out` and
  `response_status=opted_out` IMMEDIATELY. Never contact them again.
- Otherwise set `outreach_status=replied` and `response_status` to
  replied / interested / not_interested based on tone.

## 3) GUARDRAILS
- Daily capacity and score threshold come from LeadConfig (defaults: 5 outreach, threshold 45).
- Max 30 website visits this run. One site at a time (1 concurrent browser session).
- Never contact a business that already exists in Prospect. One outreach per prospect, no follow-ups.
- On errors: back off, retry max 3 times.

## 4) DISCOVER
Pick today's niche by rotating through `LeadConfig.niches` by day of month.
Search a local-business directory / maps / web search for `"<niche> in <target_location>"`.
Collect: business name, website URL, phone (if shown).

## 5) FOR EACH CANDIDATE (until daily capacity reached or 30 visits used)

**a. Duplicate check** — `duplicate_check_key = lower(business_name) + "|" + website domain`.
If a Prospect with this key exists, skip the business entirely.

**b. Analyze** — run `website-analyzer.py "<website_url>" --contact-paths /contact,/about`.
Returns JSON: `score` (0-100), `score_breakdown`, `data`, `ok`.

**c. Score above threshold** — not a prospect. Create Prospect with `quality_score`,
`outreach_status=discovered`, `notes="score above threshold"`. Move on.

**d. Missing essentials** (`ok=false`, or no business name, or no phone AND no email) —
create Prospect with `outreach_status=failed_scrape` and the reason in `notes`. Skip.

**e. Qualified** — create Prospect with `outreach_status=qualified`, `business_name`, `niche`,
`location`, `website_url`, `quality_score`, `duplicate_check_key`, and the full `scraped_data` JSON.

**f. Generate enhanced site** — write a complete, modern, mobile-responsive single-file HTML site
using ONLY the real scraped data:
- Hero section (real business name + hero line)
- Services grid (their real services)
- About section (their real about text)
- Features section
- Contact section with CTA and their real phone / email / address
- Their real brand colors and logo if available
- Modern CSS: grid, flexbox, custom properties
- Top banner: `Preview created by <sender_name> — not the live site`
Save to a file, then upload it and capture the returned public URL.

**g. Store** — create GeneratedSite (prospect_id, html_content, public_url, version=1,
generated_at=now). Update Prospect: `enhanced_site_url`, `outreach_status=site_generated`.

**h. Outreach**
- *If an email was found:* send via Gmail API (proper MIME message).
  Subject: creative and specific, e.g. `I rebuilt <Business Name>'s website — take a look`.
  Body: 1–2 sentences referencing specific REAL observations about their actual site,
  the preview link, an offer to make it live, then sender_name, physical_address, and
  `Reply 'unsubscribe' and I'll never email you again.`
  If sending fails twice, fall back to their contact form.
- *If no email:* use browser automation to open their contact form and fill name, email, and
  message with the outreach text + preview link. Max 2 attempts; if it fails,
  set `outreach_status=manual_review` and move on.

**i. Log** — create OutreachLog (prospect_id, method, exact message_body, sent_at,
status=sent/failed, error_message if any). Update Prospect: `outreach_status=contacted`,
`outreach_method`, `outreach_date=today`, `response_status=no_response`.

## 6) REPORT
Post a short summary (<150 words): businesses analyzed, qualified, sites generated,
outreach sent (email vs form), failures and manual reviews, plus today's date.
