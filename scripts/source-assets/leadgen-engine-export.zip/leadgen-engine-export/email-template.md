# Outreach email template

Rules: personalized, never generic. Reference 1–2 specific REAL things about their actual
site. One email per business, ever. Sender identity + physical address + opt-out line required.

---

**Subject options** (pick/customize based on what you found):

- `I rebuilt <Business Name>'s website — take a look`
- `<Business Name> + a faster mobile site (2-min preview)`
- `Made you something, <Business Name>`

---

**Body:**

```
Hi <Business Name> team,

I came across <Business Name> while looking at <niche> options in <city> — <specific real
detail: e.g. "your 12 years serving Indiranagar" or "your before/after gallery"> genuinely
stood out.

While I was there I noticed <specific real issue: e.g. "the site doesn't reflow on mobile"
or "the menu doesn't load on phones">, so I went ahead and rebuilt it as a modern,
mobile-first version:

<preview_link>

It's a free preview, no strings attached. Take a look, and if you like it, just reply and
we can talk about putting it live (or handing you the files).

Either way, thanks for reading.

<sender_name>
<sender_email>
<physical_address>

Prefer not to hear from me? Reply "unsubscribe" and I'll remove you immediately.
```

---

**Personalization source:** the `data` block from `website-analyzer.py` —
`services`, `about_text`, `social_links`, `brand_colors`, `score_breakdown` notes
(e.g. missing viewport → "doesn't reflow on mobile"; 0 social links → "hard to find you
on social"; no contact info → "no click-to-call on mobile").

**Never invent** a detail that isn't in the scraped data.

---

**Fallback: contact form message**

```
Hi <Business Name> team,

I'm <sender_name> — I came across your site while looking at <niche> in <city>, and I
noticed <specific issue>. So I rebuilt a modern, mobile-friendly version of it here:

<preview_link>

It's free to look at, and if you like it I'd be glad to make it live for you. Happy to
answer any questions.

<sender_name>
<sender_email>
<physical_address>
```
