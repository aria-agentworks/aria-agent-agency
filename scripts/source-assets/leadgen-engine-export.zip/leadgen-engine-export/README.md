# Automated Lead-Generation Engine — Portable Export

A complete, self-contained spec for running the local-business lead-gen pipeline in
**any** tool/agent platform. Nothing here is platform-specific except the optional
Base44 workflow file (Appendix).

---

## What it does

1. **Discover & qualify** — find local businesses in a niche + city whose websites are weak.
2. **Scrape** — pull their real brand/content data.
3. **Generate** — build a modern, responsive enhanced version of their site.
4. **Host** — upload it and get a public shareable link.
5. **Outreach** — send ONE personalized email ("I made an enhanced version of your site,
   tell me if you like it"), falling back to their web contact form.
6. **Track** — log every action, honor opt-outs, report weekly.

---

## Configuration (fill this in first)

| Field | Value |
|---|---|
| `target_location` | _e.g. "Bengaluru, India"_ |
| `niches` | _e.g. ["dentist", "gym", "salon", "spa"]_ |
| `daily_capacity` | `5` |
| `quality_score_threshold` | `45` |
| `sender_name` | _your name_ |
| `sender_email` | _your Gmail_ |
| `physical_address` | _required for CAN-SPAM_ |
| `enabled` | `false` until you're ready |

See `config-template.json`.

---

## Data model (4 tables)

See `schemas.json` for full JSON Schemas.

- **Prospect** — business_name, niche, location, website_url, quality_score,
  scraped_data (object), enhanced_site_url, email, outreach_method, outreach_status,
  outreach_date, response_status, duplicate_check_key, notes
- **LeadConfig** — target_location, niches[], daily_capacity, quality_score_threshold,
  enabled, sender_name, sender_email, physical_address, last_run_date
- **OutreachLog** — prospect_id, method, message_body, sent_at, status, error_message
- **GeneratedSite** — prospect_id, html_content, public_url, generated_at, version

**Status flow:** discovered → qualified → site_generated → contacted →
replied / manual_review / opted_out / failed_scrape

---

## The analyzer (`website-analyzer.py`)

Stdlib-only Python. Fetches a homepage plus `/contact` and `/about`, scores the site
0–100, and extracts real business data as JSON.

```
python3 website-analyzer.py "https://business-site.com" --contact-paths /contact,/about
```

**Scoring (100 pts):** SSL 15 · mobile viewport 15 · responsive CSS 15 ·
modern framework 15 · contact info 10 · social presence 10 · design quality 15

Calibration verified: modern sites score 75+, bare-bones sites ~30.
**Only proceed when score <= 45.**

Output includes: `score`, `score_breakdown`, `data` (business_name, phone, emails,
address_hint, social_links, services[], about_text, hero_text, brand_colors, logo_url),
`raw_text_excerpt`, `ok` (false when essentials are missing → skip that business).

---

## The pipeline prompt

`pipeline-prompt.md` contains the full step-by-step instruction set. Paste it into the
scheduling tool of your choice (as a cron/scheduled agent task). It is written
tool-agnostically: "run_skill/analyzer", "upload the file and get a public URL",
"send via your email connector".

---

## Rules baked into the pipeline

- Never outreach the same business twice (duplicate check on normalized name + domain).
- Max 5 businesses/day (adjustable).
- One outreach per prospect. No follow-ups.
- Honor opt-out / unsubscribe requests immediately, permanently.
- Never fabricate business information — use only scraped data.
- Back off on errors, max 3 retries per step.
- Sender identity + physical address in every email (CAN-SPAM).
- Rate limit: 1 concurrent browser session, max 30 site visits per run.
- Contact form: max 2 attempts, then flag for manual review.

---

## Schedule

- **Daily pipeline:** weekdays at 04:00 in your timezone.
- **Weekly digest:** Fridays at 17:00 — outreach sent, replies, opt-outs, failures.

Any scheduler works (`0 4 * * 1-5`, `0 17 * * 5`). See `workflows.jsonc` if you want to
import the Base44-native versions.

---

## Outreach email template

See `email-template.md`.

---

## Credits note

An LLM-driven pipeline run costs roughly one agent turn plus browser/LLM calls per
prospect. Budget ~5–30 agent turns/week depending on daily capacity. If credits are
tight: lower `daily_capacity` to 2, or run the pipeline 2–3 days/week instead of 5.
